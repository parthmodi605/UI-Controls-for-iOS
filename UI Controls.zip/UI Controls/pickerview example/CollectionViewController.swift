//
//  CollectionViewController.swift
//  UI Controls
//
//  Created by TOPS on 1/9/18.
//  Copyright © 2018 Tops. All rights reserved.
//

import UIKit

class CollectionViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
    
    var arr = ["Football","Tennis","Baseball","Basketball","Shuttercock","Gym"]
    var arr1 = [#imageLiteral(resourceName: "football"),#imageLiteral(resourceName: "tennis"),#imageLiteral(resourceName: "baseball"),#imageLiteral(resourceName: "basketball"),#imageLiteral(resourceName: "shuttercock"),#imageLiteral(resourceName: "dumbbell")]
    
    @IBOutlet weak var collectionview: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! Customcell
        cell.Lbl1.text = arr[indexPath.row]
        cell.Img1.image = arr1[indexPath.row]
        
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        if kind == UICollectionElementKindSectionHeader
        {
            let view1 = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionElementKindSectionHeader, withReuseIdentifier: "header", for: indexPath) as! reusablecell
            view1.header.text = "Sports"
            
            return view1
            
        }
        else
        {
            let view2 = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionElementKindSectionFooter, withReuseIdentifier: "footer", for: indexPath) as! reusablecell
            view2.footer.text = "Stop"
            return view2
        }
    }
    
    
    
    
    func collectionView(_ collectionView: UICollectionView, shouldSelectItemAt indexPath: IndexPath) -> Bool {
        let alert = UIAlertController(title:"\(arr[indexPath.row])" , message: "You selected this", preferredStyle: .alert)
        
        
        let button = UIAlertAction(title: "OK", style: .default)
        
        
        
        alert.addAction(button)
        
        self.present(alert, animated: true, completion: nil)
        
        return true
    }
    
    
    
    @IBAction func deletebtn(_ sender: UIButton)
    {
        let row = sender.tag
        arr.remove(at: row)
        arr1.remove(at: row)
        collectionview.reloadData()
    }
    
    //    func collectionView(_ collectionView: UICollectionView, shouldShowMenuForItemAt indexPath: IndexPath) -> Bool {
    //        return true
    //    }
    
    @IBAction func refreshBtn(_ sender: UIButton)
    {
        arr = ["Football","Tennis","Baseball","Basketball","Shuttercock","Gym"]
        arr1 = [#imageLiteral(resourceName: "football"),#imageLiteral(resourceName: "tennis"),#imageLiteral(resourceName: "baseball"),#imageLiteral(resourceName: "basketball"),#imageLiteral(resourceName: "shuttercock"),#imageLiteral(resourceName: "dumbbell")]
        
        collectionview.reloadData()
    }
    
    
    
}

class Customcell: UICollectionViewCell
{
    
    @IBOutlet weak var Img1: UIImageView!
    
    @IBOutlet weak var Lbl1: UILabel!
    
}

class reusablecell: UICollectionReusableView
{
    @IBOutlet weak var footer: UILabel!
    
    @IBOutlet weak var header: UILabel!
    
}


//
//  CollectionViewController.swift
//  UI Controls
//
//  Created by TOPS on 1/9/18.
//  Copyright © 2018 Tops. All rights reserved.
//

import UIKit

class CollectionViewController: UICollectionViewController {

    
    
    @IBOutlet weak var collectionvie: UICollectionView!
    
    var arr = ["Volleyball","Baseball","Tennis","Shuttercock","Football","Gym","Basketball"]
    var arr1 = [#imageLiteral(resourceName: "volleyball"),#imageLiteral(resourceName: "baseball"),#imageLiteral(resourceName: "tennis"),#imageLiteral(resourceName: "shuttercock"),#imageLiteral(resourceName: "football"),#imageLiteral(resourceName: "dumbbell"),#imageLiteral(resourceName: "basketball")]
    override func viewDidLoad() {
        super.viewDidLoad()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Register cell classes
       // self.collectionView!.register(UICollectionViewCell.self, forCellWithReuseIdentifier: reuseIdentifier)

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using [segue destinationViewController].
        // Pass the selected object to the new view controller.
    }
    */

    // MARK: UICollectionViewDataSource

    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }


    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        return arr.count
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! customcell
    
        cell.lbl1.text = arr[indexPath.row]
        cell.img1.image = arr1[indexPath.row]
        // Configure the cell
    
        return cell
    }
    
    
    

    // MARK: UICollectionViewDelegate

    
    // Uncomment this method to specify if the specified item should be highlighted during tracking
    override func collectionView(_ collectionView: UICollectionView, shouldHighlightItemAt indexPath: IndexPath) -> Bool {
        return true
    }
    

    
    // Uncomment this method to specify if the specified item should be selected
    override func collectionView(_ collectionView: UICollectionView, shouldSelectItemAt indexPath: IndexPath) -> Bool {
        
        let alert = UIAlertController(title: arr[indexPath.row] , message: "You selected this", preferredStyle: .alert)
        
        
        let button = UIAlertAction(title: "OK", style: .default)
        
        
        
        alert.addAction(button)
        
        self.present(alert, animated: true, completion: nil)
        return true
    }


    @IBAction func DeleteBtn(_ sender: UIButton) {
        
        let data = sender.tag
        arr.remove(at: data)
        arr1.remove(at: data)
        collectionvie.reloadData()
    }
    
    @IBAction func RefreshBtn(_ sender: UIButton) {
         arr = ["Volleyball","Baseball","Tennis","Shuttercock","Football","Gym","Basketball"]
         arr1 = [#imageLiteral(resourceName: "volleyball"),#imageLiteral(resourceName: "baseball"),#imageLiteral(resourceName: "tennis"),#imageLiteral(resourceName: "shuttercock"),#imageLiteral(resourceName: "football"),#imageLiteral(resourceName: "dumbbell"),#imageLiteral(resourceName: "basketball")]
        
        collectionvie.reloadData()
    }
    override func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        if kind == UICollectionElementKindSectionFooter
        {
            let view1 = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionElementKindSectionHeader, withReuseIdentifier: "header", for: indexPath) as! reusablecell
            view1.header.text = "Sports"
            return view1
        }
        else
        {
            let view2 = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionElementKindSectionFooter, withReuseIdentifier: "footer", for: indexPath) as! reusablecell
            view2.footer.text = "End"
            return view2
        }
    }
    
    // Uncomment these methods to specify if an action menu should be displayed for the specified item, and react to actions performed on the item
    override func collectionView(_ collectionView: UICollectionView, shouldShowMenuForItemAt indexPath: IndexPath) -> Bool {
        return true
            }

    override func collectionView(_ collectionView: UICollectionView, canPerformAction action: Selector, forItemAt indexPath: IndexPath, withSender sender: Any?) -> Bool {
        return true
    }

}

class customcell: UICollectionViewCell{
    @IBOutlet weak var img1: UIImageView!
    
    @IBOutlet weak var lbl1: UILabel!
}

class reusablecell: UICollectionReusableView
{
    @IBOutlet weak var header: UILabel!
    
    @IBOutlet weak var footer: UILabel!
    
    
}

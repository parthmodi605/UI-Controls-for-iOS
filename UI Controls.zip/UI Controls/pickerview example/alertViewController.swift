//
//  alertViewController.swift
//  UI Controls
//
//  Created by tops on 10/09/1939 Saka.
//  Copyright © 1939 Saka Tops. All rights reserved.
//

import UIKit

class alertViewController: UIViewController {

    
    @IBAction func alertButton(_ sender: UIButton) {
        
        let alertview = UIAlertController(title: "You Are Seeing .Alert Style ", message: "Thank You", preferredStyle: .alert)
        let addaction = UIAlertAction(title: "OK!", style:.default, handler: nil)
        alertview.addAction(addaction)
        self.present(alertview, animated: true, completion: nil)
    }
    
    
    @IBAction func ActionSheetButton(_ sender: UIButton) {
        
        let alertview = UIAlertController(title: "You Are Seeing .ActionSheet Style ", message: "Thank You", preferredStyle: .actionSheet)
        let addaction = UIAlertAction(title: "OK!", style:.default, handler: nil)
        alertview.addAction(addaction)
        self.present(alertview, animated: true, completion: nil)

    }
    
    @IBOutlet weak var txt1: UITextView!
    @IBAction func AlertButtonWithTextbox(_ sender: UIButton) {
        
        let alert = UIAlertController(title: "Enter Something", message: "Write What you Like", preferredStyle: .alert)
        
        alert.addTextField(configurationHandler: {(txtf) in txtf.placeholder = "Write Here"})
        
        
        let button = UIAlertAction(title: "Done", style: .default, handler:{(UIAlertAction) in
            
            
            let txtf = alert.textFields?[0]
            
            let name = txtf?.text
            
            
            
            self.txt1.insertText("\(name!)\n")
        })
        
        
        
        
        alert.addAction(button)
        
        self.present(alert, animated: true, completion: nil)
        
        
    }
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func backButton(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

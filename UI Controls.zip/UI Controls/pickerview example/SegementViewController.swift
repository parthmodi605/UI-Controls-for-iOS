//
//  SegementViewController.swift
//  UI Controls
//
//  Created by TOPS on 27/12/17.
//  Copyright © 2017 Tops. All rights reserved.
//

import UIKit

class SegementViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var txtb: UITextField!
    @IBOutlet weak var txta: UITextField!
    
    
    @IBOutlet weak var lblop: UILabel!
    
    @IBOutlet weak var lblAns: UILabel!
    
    @IBAction func ArithmaticSegmentValueChange(_ sender: UISegmentedControl) {
        
        let SelectedSegIndex = sender.selectedSegmentIndex
        
        var a = 0
        var b = 0
        if txta.text != "" && txtb.text != ""
        {
            a = Int(txta.text!)!
            b = Int(txtb.text!)!
        }
        var ans = 0
        var Operator = ""
        switch SelectedSegIndex {
        case 0:
            ans = a + b
            Operator = "+"
            break;
        case 1:
            ans = a - b
            Operator = "-"
            break;
        case 2:
            ans = a * b
            Operator = "*"
            break;
        case 3:
            ans = a / b
            Operator = "/"
            break;
        case 4:
            ans = a % b
            Operator = "%"
            break
        default:
            break;
        }
        
        lblAns.text = "\(ans)"
        lblop.text = "\(Operator)"
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    @IBAction func BackButton(_ sender: UIButton) {
        
        self.dismiss(animated: true, completion: nil)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

//
//  FrameworkViewController.swift
//  UI Controls
//
//  Created by TOPS on 29/12/17.
//  Copyright © 2017 Tops. All rights reserved.
//

import UIKit
import Contacts
import ContactsUI
import Social
import AVKit
import AVFoundation
import MapKit
import EventKit
import EventKitUI

class FrameworkViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    
    var arr = ["Contacts & ContactsUI","Social","AVKIT & AVFoundation","Mapkit","Event Kit & EventKITUI"]
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        cell?.textLabel?.text = arr[indexPath.row]
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0
        {
            let sec=storyboard?.instantiateViewController(withIdentifier: "contacts") 
             navigationController?.pushViewController(sec!, animated: true)
        }
        if indexPath.row == 1
        {
            let sec=storyboard?.instantiateViewController(withIdentifier: "social")
            navigationController?.pushViewController(sec!, animated: true)
        }
        if indexPath.row == 2
        {
            let sec=storyboard?.instantiateViewController(withIdentifier: "avkit")
            navigationController?.pushViewController(sec!, animated: true)
        }
        if indexPath.row == 3
        {
            let sec=storyboard?.instantiateViewController(withIdentifier: "mapkit")
            navigationController?.pushViewController(sec!, animated: true)
        }
        if indexPath.row == 4
        {
            let sec=storyboard?.instantiateViewController(withIdentifier: "eventkit")
            navigationController?.pushViewController(sec!, animated: true)
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}





class ContactsFrameworkViewController: UIViewController
{
    
    @IBAction func Button(_ sender: UIButton) {
        
        let contact = CNContactPickerViewController()
        present(contact, animated: true, completion: nil)
    }
    
    
}







class SocialFrameworkViewController: UIViewController
{
    
    @IBAction func buttonfb(_ sender: UIButton) {
        
        let fb = SLComposeViewController(forServiceType: SLServiceTypeFacebook)
        present(fb!, animated: true, completion: nil)
    }
    
    @IBAction func buttontw(_ sender: UIButton) {
        
        let twt = SLComposeViewController(forServiceType: SLServiceTypeTwitter)
        present(twt!, animated: true, completion: nil)
    }
    
}





class AVFrameworkViewController: UIViewController
{
    var plrobj = AVPlayer()
    var plyr = AVPlayerViewController()
    
    @IBAction func VideoButton(_ sender: UIButton) {
        
        let path = URL(fileURLWithPath: Bundle.main.path(forResource: "CGI Animated Short Film HD- 'Spellbound Short Film' by Ying Wu & Lizzia Xu", ofType: "3gp")!)
        plrobj = AVPlayer(url: path)
        plyr.player = plrobj
        plrobj.play()
        present(plyr, animated: true, completion: nil)
        
    }
    
    @IBAction func AudioButton(_ sender: UIButton) {
        
        let path = URL(fileURLWithPath: Bundle.main.path(forResource: "Swag Se Swagat(WapKing)", ofType: "mp3")!)
        plrobj = AVPlayer(url: path)
        plyr.player = plrobj
        plrobj.play()
        present(plyr, animated: true, completion: nil)

    }
    
    
}





class MapFrameworkViewController: UIViewController
{
    
    @IBOutlet weak var mapf: MKMapView!
    override func viewDidLoad() {
        super.viewDidLoad()
        //        22.308023,73.183422,
        let location = CLLocationCoordinate2DMake(22.308023, 73.183422)
        let span = MKCoordinateSpanMake(0.0002, 0.0002)
        let region = MKCoordinateRegion(center: location, span: span)
        
        mapf.setRegion(region, animated: true)
        
        let annotation = MKPointAnnotation()
        annotation.coordinate = location
        annotation.title = "Tops Technologies"
        annotation.subtitle = "Vadodara"
        mapf.addAnnotation(annotation)
        
        
    }

    
}





class EventFrameworkViewController: UIViewController
{
    let event = EKEventStore()
    let reminder = [EKReminder]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        event.requestAccess(to: .event, completion: {ACTION in
            print("Calender Access!")
        })
        event.requestAccess(to: .reminder, completion: {ACTION in
            print("Reminder Access!")
        })
        
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func EventButton(_ sender: UIButton) {
       
        let setevent = EKEvent(eventStore: event)
        setevent.title = "Birthday!"
        setevent.notes = "Happy Birthday Parth...😎😜"
        setevent.startDate = Date()
        setevent.endDate = Date()
        setevent.location = "Ahmedabad"
        
        setevent.calendar = event.defaultCalendarForNewEvents
        
        do
        {
            try event.save(setevent, span: .thisEvent)
            print("Event Added Success!")
            let alert=UIAlertController(title: "Success", message: "Event has been successfully created!", preferredStyle: .alert)
            let ok=UIAlertAction(title: "OK", style: .cancel, handler: {ACTION in
                
                self.view.backgroundColor=UIColor.purple
                
            })
            let mor=UIAlertAction(title: "MORE", style: .destructive, handler: nil)
            alert.addAction(ok)
            alert.addAction(mor)
            present(alert, animated: true, completion: nil)
        }
        catch
        {
            print("Event Fail!")
        }
        
            
        
        
    }
    
    @IBAction func ReminderButton(_ sender: UIButton) {
        
        
}

}

//
//  selectdataViewController.swift
//  pickerview example
//
//  Created by Tops on 30/11/17.
//  Copyright © 2017 Tops. All rights reserved.
//

import UIKit

class selectdataViewController: UIViewController,UIPickerViewDelegate,UIPickerViewDataSource {

    @IBOutlet weak var lbl1: UILabel!
    @IBOutlet weak var picker: UIPickerView!
    
    var arr = ["gujarat","chennai","MP","rajasthan","goa"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return arr.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return arr[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
       lbl1.text=arr[row]
        let alertview = UIAlertController(title: "selected", message: "\(lbl1.text!)", preferredStyle: .alert)
        let alertaction = UIAlertAction(title: "OK!", style: .default)
        alertview.addAction(alertaction)
        self.present(alertview, animated: true)
    }
    @IBAction func backButton(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

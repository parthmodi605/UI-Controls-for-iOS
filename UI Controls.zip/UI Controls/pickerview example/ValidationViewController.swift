//
//  ValidationViewController.swift
//  UI Controls
//
//  Created by tops on 13/09/1939 Saka.
//  Copyright © 1939 Saka Tops. All rights reserved.
//

import UIKit

class ValidationViewController: UIViewController {

    
    
    @IBOutlet weak var username: TextFieldValidator!
    
    @IBOutlet weak var email: TextFieldValidator!
    
    @IBOutlet weak var mobile: TextFieldValidator!
    
    @IBOutlet weak var pass: TextFieldValidator!
    
    
    @IBOutlet weak var confirm: TextFieldValidator!
    
    
    let REGEX_USER_NAME_LIMIT = "^.{3,10}$"
    let REGEX_USER_NAME = "[A-Za-z0-9]{3,10}"
    let REGEX_EMAIL = "[A-Z0-9a-z._%+-]{3,}+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
    let REGEX_PASSWORD_LIMIT = "^.{6,20}$"
    let REGEX_PASSWORD = "[A-Za-z0-9]{6,20}"
    let REGEX_PHONE_DEFAULT = "[0-9]{3}\\-[0-9]{3}\\-[0-9]{4}"
    
    override func viewDidLoad() {
        super.viewDidLoad()

        email.addRegx(REGEX_EMAIL, withMsg: "Enter Valid EmailID!")
        confirm.addConfirmValidation(to:pass, withMsg: "confirm Password not match!")
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func button(_ sender: UIButton) {
        
        let isuserok = username.validate()
        let isemailok = email.validate()
        let ismobileok = mobile.validate()
        let ispasswordok = pass.validate()
        let isconfirmok = confirm.validate()
        if isuserok && isemailok && ismobileok && ispasswordok && isconfirmok
        {
            performSegue(withIdentifier: "go", sender: self)
        }
    }
    
    @IBAction func backButton(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

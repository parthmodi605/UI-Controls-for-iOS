//
//  uiprogressviewViewController.swift
//  UI Controls
//
//  Created by tops on 13/09/1939 Saka.
//  Copyright © 1939 Saka Tops. All rights reserved.
//

import UIKit

class uiprogressviewViewController: UIViewController {

    
    @IBOutlet weak var lbl1: UILabel!
    
    @IBOutlet weak var progress: UIProgressView!
    
    var p = 0.0
    var thread:Timer = Timer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        thread = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(doprogress), userInfo: nil, repeats: true)

        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func doprogress()
    {
        if p<=1.00
        {
            p+=0.01
            progress.setProgress(Float(p), animated: true)
            let temp = p*100
            lbl1.text = "\(temp)%"
        }
        else
        {
            self.thread.invalidate()
        }
    }
    
    @IBAction func backButton(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

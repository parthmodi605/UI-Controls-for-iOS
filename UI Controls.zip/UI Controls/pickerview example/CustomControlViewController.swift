//
//  CustomControlViewController.swift
//  UI Controls
//
//  Created by tops on 04/10/1939 Saka.
//  Copyright © 1939 Saka Tops. All rights reserved.
//

import UIKit

class CustomControlViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
        @IBOutlet weak var txtfield: UITextField!
        @IBOutlet weak var tableview: UITableView!
        
        var IsHide:Bool = true
        
        let time = 0.3
        
        var arr = ["11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30"]
        
        override func viewDidLoad() {
            super.viewDidLoad()
            
            tableview.alpha=0
            
            // Do any additional setup after loading the view, typically from a nib.
        }
        
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            // Dispose of any resources that can be recreated.
        }
        
        @IBAction func dropButton(_ sender: UIButton) {
            
            if IsHide{
                
                IsHide = false
                
                
                UIView.animate(withDuration: time, delay: 0, options: .curveEaseIn, animations: {
                    self.tableview.alpha = 1
                }) { _ in
                    
                    
                }
                
                
            }
            else{
                
                IsHide = true
                
                
                UIView.animate(withDuration: time, delay: 0, options: .curveEaseOut, animations: {
                    self.tableview.alpha = 0
                }) { _ in
                    
                    
                }
                
            }
            
        }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        
        cell?.textLabel?.text = arr[indexPath.row]
        
        return cell!
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        txtfield.text = arr[indexPath.row]
        
        IsHide = true
        
        UIView.animate(withDuration: time, delay: 0, options: .curveEaseOut, animations: {
            self.tableview.alpha = 0
        }) { _ in
            
            
        }
        
    }
   
    @IBAction func backbutton(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }

    }

//
//  imagepickerViewController.swift
//  UI Controls
//
//  Created by tops on 10/09/1939 Saka.
//  Copyright © 1939 Saka Tops. All rights reserved.
//

import UIKit

class imagepickerViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    
    var pickerviewcontroller: UIImagePickerController!
    @IBOutlet weak var img1: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func setButton(_ sender: UIButton) {
        
        pickerviewcontroller = UIImagePickerController()
        pickerviewcontroller.delegate = self
        pickerviewcontroller.sourceType = .savedPhotosAlbum
        self.present(pickerviewcontroller, animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let image = info[UIImagePickerControllerOriginalImage] as! UIImage
        img1.image = image
        self.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func backButton(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

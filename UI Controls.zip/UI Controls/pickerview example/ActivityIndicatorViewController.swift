//
//  ActivityIndicatorViewController.swift
//  UI Controls
//
//  Created by tops on 13/09/1939 Saka.
//  Copyright © 1939 Saka Tops. All rights reserved.
//

import UIKit

class ActivityIndicatorViewController: UIViewController {
    @IBOutlet weak var Indicator: UIActivityIndicatorView!
    var thread:Timer = Timer()
    var i = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        Indicator.startAnimating()
        thread = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(doindicatorprogress), userInfo: nil, repeats: true)
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func doindicatorprogress(){
        if i<5
        {
            i+=1
        }
        else{
            Indicator.stopAnimating()
            Indicator.hidesWhenStopped = true
            thread.invalidate()
            let sec=storyboard?.instantiateViewController(withIdentifier: "main")
            navigationController?.pushViewController(sec!, animated: true)

        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

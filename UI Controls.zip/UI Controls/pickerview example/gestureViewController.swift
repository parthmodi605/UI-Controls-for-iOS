//
//  gestureViewController.swift
//  UI Controls
//
//  Created by tops on 13/09/1939 Saka.
//  Copyright © 1939 Saka Tops. All rights reserved.
//

import UIKit


class select:UIViewController,UITableViewDataSource,UITableViewDelegate
{
    
    var arr = ["Tap","Pinch","Rotate","Swipe","Pan","Long Press"]
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        cell?.textLabel?.text = arr[indexPath.row]
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0
        {
            let sec=storyboard?.instantiateViewController(withIdentifier: "Tap")
            navigationController?.pushViewController(sec!, animated: true)
        }
        if indexPath.row == 1
        {
            let sec=storyboard?.instantiateViewController(withIdentifier: "Pinch")
            navigationController?.pushViewController(sec!, animated: true)
        }
        if indexPath.row == 2
        {
            let sec=storyboard?.instantiateViewController(withIdentifier: "Rotate")
            navigationController?.pushViewController(sec!, animated: true)
        }
        if indexPath.row == 3
        {
            let sec=storyboard?.instantiateViewController(withIdentifier: "Swipe")
            navigationController?.pushViewController(sec!, animated: true)
        }
        if indexPath.row == 4
        {
            let sec=storyboard?.instantiateViewController(withIdentifier: "Pan")
            navigationController?.pushViewController(sec!, animated: true)
        }
        if indexPath.row == 5
        {
            let sec=storyboard?.instantiateViewController(withIdentifier: "Long Press")
            navigationController?.pushViewController(sec!, animated: true)
        }
    }
}
class tapgestureViewController: UIViewController {
    var istapped = false
    var scal = CGAffineTransform()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        scal = CGAffineTransform.init(scaleX: 1, y: 1)

        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var Image: UIImageView!

    @IBAction func Tapgest(_ sender: UITapGestureRecognizer) {
        if istapped{
           Image.transform=CGAffineTransform.init(scaleX: 10.0, y: 10.0)
            istapped=false
        }
        else
        {
            Image.transform=CGAffineTransform.init(scaleX: 1.0, y: 1.0)
            istapped=true
        }
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func backButton(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }

    
}




class PinchgestureViewController: UIViewController {
        
        override func viewDidLoad() {
            super.viewDidLoad()
            
            // Do any additional setup after loading the view.
        }
        
    @IBOutlet weak var image: UIImageView!
    @IBAction func pinchgest(_ sender: UIPinchGestureRecognizer) {
        
        image.transform = CGAffineTransform.init(scaleX: sender.scale, y: sender.scale)
        
        
    }
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            // Dispose of any resources that can be recreated.
        }
    
    
    @IBAction func backButton(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }


}




class RotategestureViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var image: UIImageView!
    @IBAction func rotgest(_ sender: UIRotationGestureRecognizer) {
    
        image.transform = CGAffineTransform.init(rotationAngle: sender.rotation)
    
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func backButton(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }

    
}


class SwipegestureViewController: UIViewController {
    @IBOutlet weak var image1: UIImageView!
    
    let arr = [#imageLiteral(resourceName: "img1"),#imageLiteral(resourceName: "img2"),#imageLiteral(resourceName: "img3"),#imageLiteral(resourceName: "img4")]
    
    var i = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
    @IBAction func rightSwipeOnImage(_ sender: UISwipeGestureRecognizer) {
        if i > 0
        {
            i -= 1
        }
        
        image1.image = arr[i]
    }
    @IBAction func leftSwipeOnImage(_ sender: UISwipeGestureRecognizer) {
        
        if i < 3
        {
            i += 1
        }
        
        image1.image = arr[i]
    }
}


class PangestureViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var image: UIImageView!
    @IBAction func pangest(_ sender: UIPanGestureRecognizer) {
        
        let point = sender.translation(in: self.view)
        
        image.transform = CGAffineTransform.init(translationX: point.x, y: point.y)
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func backButton(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }

}


class LongPressgestureViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        Deletebtn.isHidden = true
        
        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var image: UIImageView!
    
    @IBOutlet weak var Deletebtn: UIButton!
    @IBAction func longgest(_ sender: UILongPressGestureRecognizer) {
        Deletebtn.isHidden = false
    }
    
    
    @IBAction func BtnDelete(_ sender: UIButton) {
        if image.alpha == 1.0{
            Deletebtn.setTitle("Undo", for: .normal )
            image.alpha = 0.0}
        else{
            Deletebtn.isHidden = true
            image.alpha = 1.0}
        }
        
    

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func backButton(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }

}



//
//  ViewController.swift
//  pickerview example
//
//  Created by Tops on 30/11/17.
//  Copyright © 2017 Tops. All rights reserved.
//

import UIKit

class pickerSelectViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    var arr = ["Simple Picker View","2 Picker View","Add Data In Picker View","Select Data From Picker View","Image Picker View"]
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
        
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        cell?.textLabel?.text = arr[indexPath.row]
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0
        {
            let sec=storyboard?.instantiateViewController(withIdentifier: "simple")
            navigationController?.pushViewController(sec!, animated: true)
        }
        if indexPath.row == 1
        {
            let sec=storyboard?.instantiateViewController(withIdentifier: "2")
            navigationController?.pushViewController(sec!, animated: true)
        }
        if indexPath.row == 2
        {
            let sec=storyboard?.instantiateViewController(withIdentifier: "add data")
            navigationController?.pushViewController(sec!, animated: true)
        }
        if indexPath.row == 3
        {
            let sec=storyboard?.instantiateViewController(withIdentifier: "select data")
            navigationController?.pushViewController(sec!, animated: true)
        }
        if indexPath.row == 4
        {
            let sec=storyboard?.instantiateViewController(withIdentifier: "image")
            navigationController?.pushViewController(sec!, animated: true)
        }
    }

}

